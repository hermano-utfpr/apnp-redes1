#!/usr/bin/perl

system("iptables -I INPUT -p tcp --dport 80 -j REJECT");


