#!/usr/bin/perl

system("cp /opt/google/var/www/html/* /var/www/html/");
system("/etc/init.d/lighttpd restart");

while (1) {
   system("clear");
   system("figlet google");
   $tmp = <STDIN>;
}

