#!/usr/bin/perl

system("cp /opt/router/etc/bind/* /etc/bind/");
system("cp /opt/router/var/cache/bind/* /var/cache/bind/");
system("/etc/init.d/bind9 restart");

while (1) {
   system("clear");
   system("figlet router");
   $tmp = <STDIN>;
}


