#!/usr/bin/perl 

system("ifconfig eth0 hw ether _MAC_");


