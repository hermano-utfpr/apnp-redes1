#!/usr/bin/perl

system("cp /opt/isp-router/etc/bind/* /etc/bind/");
system("cp /opt/isp-router/var/cache/bind/* /var/cache/bind/");
system("/etc/init.d/bind9 restart");

while (1) {
   system("clear");
   system("figlet isp-router");
   $tmp = <STDIN>;
}


