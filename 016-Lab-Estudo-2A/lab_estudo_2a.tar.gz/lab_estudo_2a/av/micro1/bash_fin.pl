#!/usr/bin/perl

system("ip -6 addr add fc00::1/64 dev eth0");


