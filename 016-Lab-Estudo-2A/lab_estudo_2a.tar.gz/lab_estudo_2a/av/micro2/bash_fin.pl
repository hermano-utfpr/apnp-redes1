#!/usr/bin/perl

system("ip -6 addr add fc00::2/64 dev eth0");


