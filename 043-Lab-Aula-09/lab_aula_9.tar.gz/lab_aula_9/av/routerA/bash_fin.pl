#!/usr/bin/perl

system("echo \"zebra=yes\nbgpd=yes\nospfd=yes\nospf6d=yes\nripd=yes\nripngd=yes\n\" > /etc/quagga/daemons");

system("cp /usr/share/doc/quagga/examples/zebra.conf.sample /etc/quagga/zebra.conf");
system("cp /usr/share/doc/quagga/examples/bgpd.conf.sample /etc/quagga/bgpd.conf");
system("cp /usr/share/doc/quagga/examples/ospfd.conf.sample /etc/quagga/ospfd.conf");
system("cp /usr/share/doc/quagga/examples/ospf6d.conf.sample /etc/quagga/ospf6d.conf");
system("cp /usr/share/doc/quagga/examples/ripd.conf.sample /etc/quagga/ripd.conf");
system("cp /usr/share/doc/quagga/examples/ripngd.conf.sample /etc/quagga/ripngd.conf");

system("chown quagga.quaggavty /etc/quagga/*.conf");
system("chmod 640 /etc/quagga/*.conf");
system("echo 1 > /proc/sys/net/ipv4/ip_forward");
system("/etc/init.d/quagga restart");

while (1) {

   system("clear");
   system("figlet `hostname`");

   system("env VTYSH_PAGER=more vtysh");

}


