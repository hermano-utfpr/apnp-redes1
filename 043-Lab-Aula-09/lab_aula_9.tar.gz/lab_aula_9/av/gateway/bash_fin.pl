#!/usr/bin/perl

system("dpkg --install /opt/gateway/opt/*.deb");


