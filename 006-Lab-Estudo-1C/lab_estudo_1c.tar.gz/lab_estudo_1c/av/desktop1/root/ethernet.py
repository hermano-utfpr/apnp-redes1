# Quadro Ethernet para os labs xbnet
# Autor: Hermano Pereira em 2016-09-14
# Fork de https://gist.github.com/cslarsen/11339448

import sys
from socket import *

try:
   interface = sys.argv[1]
   destino_mac = sys.argv[2]
   cargautil = sys.argv[3]
   destino_enc = "\\x"+destino_mac.replace(':','\\x')
   destino = destino_enc.decode('string_escape')
   origem_mac = open('/sys/class/net/'+interface+'/address', 'r').read().rstrip()
   origem_enc = "\\x"+origem_mac.replace(':','\\x')
   origem = origem_enc.decode('string_escape')
   tipo = "\xFF\xFF"
   assert(len(origem)==6)
   assert(len(destino)==6)
   assert(len(tipo)==2)
   soquete = socket(AF_PACKET, SOCK_RAW)
   soquete.bind((interface, 0))
   soquete.send(destino + origem + tipo + cargautil)
except:
   print ('Tente executar assim:')
   print ('python ethernet.py interface mac_destino carga_util')
   print ('Exemplo:')
   print ('python ethernet.py eth0 00:e2:01:09:01:10 "meu teste"')
   sys.exit()


