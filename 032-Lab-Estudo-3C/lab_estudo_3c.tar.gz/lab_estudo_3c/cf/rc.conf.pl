#!/usr/bin/perl

sub catch_mac {
   my $if = shift;
   my $res = qx/ifconfig $if \| egrep HW/;
   $res =~ m/(([0-9a-f]{2}\:)+([0-9a-f]{2}))/;
   return $1;
}

sub change_hostname {
   my $hostname = shift;
   system ("hostname $hostname");
   system ("echo \"127.0.0.1\t$hostname\" >> /etc/hosts\n");
}

sub network_conf {
   my $if = shift;
   my $ip = shift;
   my $mask = shift;
   if ($ip) {
      system("ifconfig ".$if." ".$ip." netmask ".$mask." up");
   }
}

sub gateway_conf {
   my $gw = shift;
   if ($gw) {
      system("route add default gw ".$gw);
   }
}

sub nameserver_conf {
   my $dns = shift;
   my $domain = shift;
   if ($dns) {
      system("echo \"nameserver ".$dns." \" > /etc/resolv.conf");
      if ($domain) {
         system("echo \"domain ".$domain." \" >> /etc/resolv.conf");
      }
   }
} 

sub route_enable {
   system("sysctl net.ipv4.ip_forward=1");
}

